<?php
require_once 'funciones.php';
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

$conn = conexionBD();
$idUsuario = $_SESSION['usuario'];
$idContacto = $_GET['id'] ?? null;

$queryAvatar = "SELECT avatar FROM usuarios WHERE id = ?";
$stmtAvatar = $conn->prepare($queryAvatar);
$stmtAvatar->bind_param('i', $idUsuario);
$stmtAvatar->execute();
$resultadoAvatar = $stmtAvatar->get_result();
$usuario = $resultadoAvatar->fetch_assoc();

if ($idContacto) {
    $query = "SELECT * FROM contactos WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $idContacto);
    $stmt->execute();
    $result = $stmt->get_result();
    $contacto = $result->fetch_assoc();

    if (!$contacto) {
        echo "El contacto no existe.";
        exit;
    }
} else {
    echo "No se especificó un contacto.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mensaje'])) {
    $nuevoMensaje = trim($_POST['mensaje']);
    if (!empty($nuevoMensaje)) {
        $queryInsert = "INSERT INTO mensajes (texto, fecha_envio, id_contacto) VALUES (?, NOW(), ?)";
        $stmtInsert = $conn->prepare($queryInsert);
        $stmtInsert->bind_param('si', $nuevoMensaje, $idContacto);
        $stmtInsert->execute();
    }
}

$queryMensajes = "SELECT texto, fecha_envio FROM mensajes WHERE id_contacto = ? ORDER BY fecha_envio ASC";
$stmtMensajes = $conn->prepare($queryMensajes);
$stmtMensajes->bind_param('i', $idContacto);
$stmtMensajes->execute();
$resultMensajes = $stmtMensajes->get_result();
$mensajes = $resultMensajes->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Contacto</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <header>
        <nav class="navbar-fixed">
            <a href="index.php"><img class="ic-back" src="img/ic-back.png" alt="Atras"></a>
            <h1>Mis Contactos</h1>
            <img class="avatar" src="avatars/<?php echo htmlspecialchars($usuario['avatar']); ?>" alt="Avatar" class="avatar">
        </nav>
    </header>

    <main>
        <section class="contacto-detalle">
            <h1>Detalle del Contacto</h1>
            <img class="foto" src="fotos/<?php echo $contacto['foto']; ?>" alt="Foto de <?php echo $contacto['nombre']; ?>" class="contacto-foto">
            <h2><?php echo $contacto['nombre'] . " " . $contacto['apellidos']; ?></h2>
            <p><?php echo $contacto['telefono']; ?></p>
        </section>

        <section class="mensajes">
            <h3>Mensajes</h3>
            <ul>
                <?php foreach ($mensajes as $mensaje): ?>
                    <li class="mensaje-li">
                        <p class="mensaje"><?php echo $mensaje['texto']; ?></p>
                        <p class="fechaEnvio"><?php echo $mensaje['fecha_envio']; ?></p>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>

        <section class="escribir">
            <form method="POST" action="detalleContacto.php?id=<?php echo $contacto['id']; ?>">
                <input class="escribir-mensaje" type="text" name="mensaje" id="mensaje" required>
                <button class="submit-btn2" type="submit">Enviar mensaje</button>
            </form>
        </section>
    </main>
</body>
</html>
