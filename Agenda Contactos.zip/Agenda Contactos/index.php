<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda - Lista de Contactos</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<?php
require_once 'funciones.php';
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

$errorRegistro = "";
$mensajeRegistro = "";

$conn = conexionBD();
$idUsuario = $_SESSION['usuario'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['buscar'])) {
    $buscar = "%" . trim($_GET['buscar']) . "%";
    $query = "SELECT * FROM contactos WHERE id_usuario = ? AND (nombre LIKE ? OR apellidos LIKE ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iss', $idUsuario, $buscar, $buscar);
} else {
    $query = "SELECT * FROM contactos WHERE id_usuario = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $idUsuario);
}
$stmt->execute();
$result = $stmt->get_result();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $apellidos = trim($_POST['apellidos']);
    $telefono = trim($_POST['telefono']);
    $foto = $_FILES['foto'];

    $fotoDir = "fotos/";
    $fotoNombre = uniqid() . "_" . basename($foto['name']);
    $fotoRuta = $fotoDir . $fotoNombre;

    if (move_uploaded_file($foto['tmp_name'], $fotoRuta)) {
        $query = "INSERT INTO contactos (nombre, apellidos, telefono, foto, id_usuario) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ssssi', $nombre, $apellidos, $telefono, $fotoNombre, $idUsuario);
        
        if ($stmt->execute()) {
            $mensajeRegistro = "Registro exitoso.";
            header("Refresh: 2; URL=index.php");
        } else {
            $errorRegistro = "Error al registrar el contacto. Intenta nuevamente.";
        }
    } else {
        $errorRegistro = "Error al subir el avatar.";
    }
}
?>
    <header>
        <nav class="navbar">
        <?php
        $queryAvatar = "SELECT avatar FROM usuarios WHERE id = ?";
        $stmtAvatar = $conn->prepare($queryAvatar);
        $stmtAvatar->bind_param('i', $idUsuario);
        $stmtAvatar->execute();
        $resultadoAvatar = $stmtAvatar->get_result();
        $usuario = $resultadoAvatar->fetch_assoc();
        ?>
        <img src="avatars/<?php echo htmlspecialchars($usuario['avatar']); ?>" alt="Avatar" class="avatar">
        </nav>
    </header>

    <main class="main-index">

        <section class="buscar-contactos">
        <h1>Mis Contactos</h1>
            <form method="GET" action="index.php">
                <input type="text" name="buscar" placeholder="Buscar contacto...">
                <button type="submit">Buscar</button>
            </form>

            <button class="crear-contacto-btn"  onclick="document.getElementById('crearContactoDialog').showModal();">Agregar Contacto</button>

            <section class="contactos">
                <ul>
                <?php while ($contacto = $result->fetch_assoc()): ?>
                    <li>
                        <a href="detalleContacto.php?id=<?php echo $contacto['id']; ?>">
                            <img class="avatar" src="fotos/<?php echo htmlspecialchars($contacto['foto']); ?>" alt="Foto de <?php echo htmlspecialchars($contacto['nombre']); ?>" class="contacto-foto">
                            <span><?php echo htmlspecialchars($contacto['nombre'] . " " . $contacto['apellidos']); ?></span>
                        </a>
                    </li>
                <?php endwhile; ?>
                </ul>
            </section>
        </section>

        <dialog class="container2" id="crearContactoDialog">
            <form class="form-container" method="POST" action="index.php" enctype="multipart/form-data">
                <h1>Crear Contacto</h1>
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" name="nombre" id="nombre" required>
                </div>
                <div class="form-group">
                    <label for="apellidos">Apellidos:</label>
                    <input type="text" name="apellidos" id="apellidos" required>
                </div>
                <div class="form-group">
                    <label for="telefono">Teléfono:</label>
                    <input type="text" name="telefono" id="telefono" required>
                </div>
                <div class="form-group">
                    <label for="foto">Foto:</label>
                    <input type="file" name="foto" id="foto" required>
                </div>

                <div class="error_message" id="error_message">
                    <?php if (isset($errorRegistro)) echo "<p class='message'>$errorRegistro</p>"; ?>
                    <?php if (isset($mensajeRegistro)) echo "<p class='message'>$mensajeRegistro</p>"; ?>
                </div>
                <button class="submit-btn2" type="submit">Guardar</button>
                <button class="submit-btn2" type="button" onclick="document.getElementById('crearContactoDialog').close();">Cancelar</button>
            </form>
        </dialog>
    </main>
</body>
</html>
