let num1 = parseInt(prompt("Ingrese el primer número:"));
let num2 = parseInt(prompt("Ingrese el segundo número:"));
let num3 = parseInt(prompt("Ingrese el tercer número:"));

if (num1 < 10 && num2 < 10 && num3 < 10) {
    document.write("Todos los números son menores a diez.");
}