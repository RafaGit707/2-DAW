let multiplo = 8;

while (multiplo <= 500) {
    document.write(multiplo + " ");
    multiplo += 8;
}