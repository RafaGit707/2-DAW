let contador = 1;
let termino = 11;

while (contador <= 25) {
    document.write(termino + " ");
    termino += 11;
    contador++;
}
