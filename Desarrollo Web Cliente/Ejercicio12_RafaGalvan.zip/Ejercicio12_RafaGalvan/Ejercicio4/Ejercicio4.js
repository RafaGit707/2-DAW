let numero = parseInt(prompt("Ingrese un número del 1 al 10:"));

for (let i = 1; i <= 12; i++) {
    document.write(numero + " x " + i + " = " + (numero * i) + "<br>");
}