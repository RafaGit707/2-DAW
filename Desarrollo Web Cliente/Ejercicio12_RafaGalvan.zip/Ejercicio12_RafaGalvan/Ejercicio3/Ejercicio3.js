for (let i = 1; i <= 10; i++) {
    document.write("5 x " + i + " = " + (5 * i) + "<br>");
}