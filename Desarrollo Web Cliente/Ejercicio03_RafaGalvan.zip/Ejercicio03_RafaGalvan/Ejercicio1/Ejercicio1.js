let N = parseInt(prompt("Ingrese un valor entero para N:"));

N += 77;

N -= 3;

N *= 2;

document.write("El valor final de N es: " + N);