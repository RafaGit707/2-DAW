let B = parseInt(prompt("Ingrese un valor entero para B:"));

if (B >= 0) {
    document.write("El valor de B es positivo.");
} else {
    document.write("El valor de B es negativo.");
}