for (let i = 10; i <= 1500; i += 10) {
    document.write(i + " ");
}