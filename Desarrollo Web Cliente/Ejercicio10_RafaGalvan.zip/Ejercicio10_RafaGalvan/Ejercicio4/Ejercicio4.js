for (let i = 1; i <= 20; i++) {
    document.write(5 * i + " ");
}