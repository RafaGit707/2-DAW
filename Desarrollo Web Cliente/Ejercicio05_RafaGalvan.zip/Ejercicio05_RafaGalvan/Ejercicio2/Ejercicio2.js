let num = parseInt(prompt("Ingrese un número entero:"));

if (num > 0) {
    document.write("El número es positivo.");
} else if (num === 0) {
    document.write("El número es cero.");
} else {
    document.write("El número es negativo.");
}